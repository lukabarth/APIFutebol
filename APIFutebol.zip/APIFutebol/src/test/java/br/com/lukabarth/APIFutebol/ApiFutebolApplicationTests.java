package br.com.lukabarth.APIFutebol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiFutebolApplicationTests {

	@Test
	void contextLoads() {
	}

}
